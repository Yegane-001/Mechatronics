import torch
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, random_split
import os
import zipfile

# 1. Mount Google Drive
from google.colab import drive
drive.mount('/content/gdrive')

# 2. Unzip the dataset

zip_path = '/content/gdrive/MyDrive/grippers_data.zip'
extract_path = '/content/dataset'

print(f"Extracting {zip_path} to {extract_path}...")
with zipfile.ZipFile(zip_path, 'r') as zip_ref:
    zip_ref.extractall(extract_path)
print("Extraction complete!")

# 3. Define Image Transformations
# Data augmentation and normalization for training
# Just normalization for validation and testing
train_transforms = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(10),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# For validation and test sets, we don't need augmentation
test_val_transforms = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# 4. Load the full dataset
# The main data folder should contain the class subfolders
data_dir = os.path.join(extract_path, os.listdir(extract_path)[0]) # Navigates into the main folder inside the zip
full_dataset = torchvision.datasets.ImageFolder(root=data_dir)

# 5. Split the dataset into training, validation, and test sets (70%, 15%, 15%)
train_size = int(0.7 * len(full_dataset))
val_size = int(0.15 * len(full_dataset))
test_size = len(full_dataset) - train_size - val_size

train_dataset, val_dataset, test_dataset = random_split(full_dataset, [train_size, val_size, test_size])

# Apply the correct transforms to each dataset split
train_dataset.dataset.transform = train_transforms
val_dataset.dataset.transform = test_val_transforms
test_dataset.dataset.transform = test_val_transforms

print(f"\nDataset split:")
print(f"Training set size: {len(train_dataset)}")
print(f"Validation set size: {len(val_dataset)}")
print(f"Test set size: {len(test_dataset)}")

# 6. Create DataLoaders
batch_size = 32
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

print("\nDataLoaders created successfully!")
print("Data is ready for training.")