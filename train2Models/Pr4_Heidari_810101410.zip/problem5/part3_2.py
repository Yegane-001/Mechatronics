from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Set the model to evaluation mode
model.eval()

# Store predictions and true labels
all_preds = []
all_labels = []

with torch.no_grad():
    for images, labels in test_loader: # Use the test_loader
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        _, predicted = torch.max(outputs.data, 1)

        all_preds.extend(predicted.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())

# --- Performance Metrics ---
print("--- Final Performance on Test Set ---")

# 1. Classification Report (Precision, Recall, F1-score)
class_names = full_dataset.classes
print(classification_report(all_labels, all_preds, target_names=class_names))

# 2. Confusion Matrix
cm = confusion_matrix(all_labels, all_preds)
df_cm = pd.DataFrame(cm, index=class_names, columns=class_names)

plt.figure(figsize=(8, 6))
sns.heatmap(df_cm, annot=True, fmt='g', cmap='Blues')
plt.title('Confusion Matrix')
plt.ylabel('Actual Label')
plt.xlabel('Predicted Label')
plt.show()