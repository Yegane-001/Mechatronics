import torch.nn as nn
import torch.nn.functional as F

# Define the custom CNN architecture
class GripperCNN(nn.Module):
    def __init__(self):
        super(GripperCNN, self).__init__()
        # --- CNN Backbone (Feature Extractor) ---
        # Block 1
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=16, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(16)
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2) # Output size: 64x64

        # Block 2
        self.conv2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(32)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2) # Output size: 32x32

        # Block 3
        self.conv3 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm2d(64)
        self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2) # Output size: 16x16

        # --- MLP Classifier ---
        # The input features to the MLP will be 64 * 16 * 16
        self.fc1 = nn.Linear(64 * 16 * 16, 512)
        self.dropout = nn.Dropout(0.5)
        self.fc2 = nn.Linear(512, 4) # 4 output classes

    def forward(self, x):
        # Pass through CNN backbone
        x = self.pool1(F.relu(self.bn1(self.conv1(x))))
        x = self.pool2(F.relu(self.bn2(self.conv2(x))))
        x = self.pool3(F.relu(self.bn3(self.conv3(x))))

        # Flatten the output for the MLP
        x = x.view(-1, 64 * 16 * 16)

        # Pass through MLP classifier
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x) # Final raw scores (logits)
        return x

# Create an instance of the model and print its structure
model = GripperCNN()
print(model)