import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import os

# --- قدم اول: تولید داده (اگر فایل وجود ندارد) ---

def forward_kinematics(theta1, theta2, theta3, l0=1, l1=1, l2=1, l3=1):
    c1, s1 = np.cos(theta1), np.sin(theta1)
    c2, s2 = np.cos(theta2), np.sin(theta2)
    c3, s3 = np.cos(theta3), np.sin(theta3)
    x = l2*c1*c2 - l1*s1 + l3*c1*c2*c3 - l3*c1*s2*s3
    y = l2*s1*c2 + l1*c1 + l3*s1*c2*c3 - l3*s1*s2*s3
    z = l0 - l2*s2 - l3*(s2*c3 + c2*s3)
    return x, y, z

file_name = 'robot_kinematics_data.csv'
if not os.path.exists(file_name):
    print("Generating dataset...")
    num_points_per_axis = 30
    theta_range = np.linspace(-np.pi, np.pi, num=num_points_per_axis)
    dataset = [['x', 'y', 'z', 'theta1', 'theta2', 'theta3']]
    for t1 in theta_range:
        for t2 in theta_range:
            for t3 in theta_range:
                pos = forward_kinematics(t1, t2, t3)
                dataset.append([pos[0], pos[1], pos[2], t1, t2, t3])
    
    pd.DataFrame(dataset[1:], columns=dataset[0]).to_csv(file_name, index=False)
    print("Dataset generation complete!")
else:
    print("Dataset file already exists.")

# --- قدم دوم: بارگذاری، فیلتر و آماده‌سازی داده‌ها ---

print("Loading and preparing data...")
df = pd.read_csv(file_name)

# داده‌ها را فیلتر می‌کنیم تا مسئله یک-به-یک شود
df_constrained = df[df['theta2'] >= 0].copy()
print(f"Original data points: {len(df)}")
print(f"Constrained data points (theta2 >= 0): {len(df_constrained)}")

# In the section "قدم دوم: بارگذاری، فیلتر و آماده‌سازی داده‌ها"
X = df_constrained[['x', 'y', 'z']].values
# Normalize the output angles to be in the [-1, 1] range
y = df_constrained[['theta1', 'theta2', 'theta3']].values / np.pi

X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.3, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)
X_test = scaler.transform(X_test)

X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
X_val_tensor = torch.tensor(X_val, dtype=torch.float32)
y_val_tensor = torch.tensor(y_val, dtype=torch.float32)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test, dtype=torch.float32)
# --- قدم سوم: ساخت و آموزش شبکه ---

class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(3, 256),
            nn.Tanh(),
            nn.Linear(256, 128),
            nn.Tanh(),
            nn.Linear(128, 64),
            nn.Tanh(),
            nn.Linear(64, 3)
        )
    def forward(self, x):
        return self.layers(x)

model = MLP()
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.0001) # <-- نرخ یادگیری را کاهش دادیم

epochs = 4000 
train_losses = []
val_losses = []

print("\nStarting training with CONSTRAINED data and POWERFUL model...")
for epoch in range(epochs):
    model.train()
    outputs = model(X_train_tensor)
    loss = criterion(outputs, y_train_tensor)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    
    model.eval()
    with torch.no_grad():
        val_outputs = model(X_val_tensor)
        val_loss = criterion(val_outputs, y_val_tensor)
    
    train_losses.append(loss.item())
    val_losses.append(val_loss.item())
    
    if (epoch + 1) % 20 == 0:
        print(f'Epoch [{epoch+1}/{epochs}], Training Loss: {loss.item():.6f}, Validation Loss: {val_loss.item():.6f}')

print("Training finished!")

# --- قدم چهارم: رسم نمودار ---
plt.figure(figsize=(10, 5))
plt.plot(train_losses, label='Training Loss')
plt.plot(val_losses, label='Validation Loss')
plt.title('Training and Validation Loss Over Epochs')
plt.xlabel('Epochs')
plt.ylabel('Loss (MSE)')
plt.legend()
plt.grid(True)
plt.show()

# --- قدم نهایی: بخش (د) - مقایسه و تست مدل ---

# 1. Select a sample from the test set
# We'll use the first sample from our test data
sample_x = X_test_tensor[0]
sample_y_actual_normalized = y_test_tensor[0]

# Add a batch dimension (required for the model)
sample_x = sample_x.unsqueeze(0)

# 2. Make a prediction with the trained model
model.eval() # Set the model to evaluation mode
with torch.no_grad():
    predicted_y_normalized = model(sample_x)

# 3. Denormalize the outputs (both predicted and actual) back to radians
# We do this by multiplying by pi
predicted_y_radians = predicted_y_normalized.squeeze(0).numpy() * np.pi
sample_y_actual_radians = sample_y_actual_normalized.numpy() * np.pi

# Convert to degrees for easier interpretation
predicted_y_degrees = np.degrees(predicted_y_radians)
sample_y_actual_degrees = np.degrees(sample_y_actual_radians)

# 4. Print and compare the results
print("\n--- Model Test on a Single Sample ---")
print(f"Input Position (x, y, z): {scaler.inverse_transform(sample_x.numpy())[0]}")
print("-" * 35)
print(f"Actual Angles (degrees):    Theta1={sample_y_actual_degrees[0]:.2f}, Theta2={sample_y_actual_degrees[1]:.2f}, Theta3={sample_y_actual_degrees[2]:.2f}")
print(f"Predicted Angles (degrees): Theta1={predicted_y_degrees[0]:.2f}, Theta2={predicted_y_degrees[1]:.2f}, Theta3={predicted_y_degrees[2]:.2f}")
print("-" * 35)

# Calculate the error for this sample in degrees
error = np.abs(predicted_y_degrees - sample_y_actual_degrees)
print(f"Error (degrees):            Theta1={error[0]:.2f}, Theta2={error[1]:.2f}, Theta3={error[2]:.2f}")
print(f"Average Error for this sample: {np.mean(error):.2f} degrees")